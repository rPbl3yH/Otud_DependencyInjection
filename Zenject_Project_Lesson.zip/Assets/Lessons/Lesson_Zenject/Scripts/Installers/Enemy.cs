using UnityEngine;

namespace Lessons.Lesson_Zenject
{
    public class Enemy : MonoBehaviour
    {
        
    }
}