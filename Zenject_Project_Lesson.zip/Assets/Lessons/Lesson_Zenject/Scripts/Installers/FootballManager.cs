using UnityEngine;

namespace Lessons.Lesson_Zenject
{
    public class FootballManager 
    {
        public FootballManager()
        {
            Debug.Log("Play football");
        }

        public void Initialize()
        {
            // Debug.Log("Play football");
        }
    }
}