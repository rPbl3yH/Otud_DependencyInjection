using UnityEngine;

namespace Lessons.Lesson_DI.Scripts.ServiceLocator
{
    public class ServiceInstaller : MonoBehaviour
    {
        
    }
}