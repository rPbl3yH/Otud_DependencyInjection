namespace Zenject
{
    public interface IAnimatorIkHandler
    {
        void OnAnimatorIk();
    }
}

