#if !NOT_UNITY3D

namespace Zenject
{
    public class DefaultGameObjectKernel : MonoKernel
    {
    }
}

#endif
